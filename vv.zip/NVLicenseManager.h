#import <Foundation/Foundation.h>
NS_ASSUME_NONNULL_BEGIN
@interface NVLicenseManager : NSObject
+ (instancetype)shared;
- (void)verifyKey:(NSString *)key completion:(void (^)(BOOL valid, NSString *message, NSDate * _Nullable expires))completion;
@end
NS_ASSUME_NONNULL_END
