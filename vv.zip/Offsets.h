#pragma once
#include <cstdint>

#define RVA_Camera_get_main                    0x8D00CE0
#define RVA_Camera_WorldToScreenPoint          0x8D005EC
#define RVA_Camera_get_pixelWidth              0x8CFFB7C
#define RVA_Camera_get_pixelHeight             0x8CFFBCC

#define RVA_Component_get_transform            0x8D5B858
#define RVA_Component_get_gameObject           0x8D5B8A8
#define RVA_Transform_get_position             0x8D6DE18

#define RVA_Player_IsDieing                    0x561E064
#define RVA_Player_IsSighting                  0x562B580
#define RVA_Player_SetAimRotation              0x563887C
#define RVA_Player_GetWeaponOnHand             0x5617A14
#define RVA_Player_GetHeadCollider             0x5636838
#define RVA_Player_TakeDamage                  0x56AA508
#define RVA_Player_StartFiring                 0x56B29C8
#define RVA_Player_StopFire                    0x56B2F10
#define RVA_Player_StartWholeBodyFiring        0x56B2C68

#define RVA_Entity_IsDead                      0x58C5F6C

#define OFFSET_Player_PlayerID                 0x408
#define OFFSET_Player_IsClientBot              0x4A0
#define OFFSET_Player_ObjectPool               0xE50
#define OFFSET_Player_Attributes               0x768
#define OFFSET_Player_AimTarget                0x738
#define OFFSET_Player_CurrentAimRotation       0x1A8C

#define OFFSET_PlayerAttributes_DamageContext  0x318

#define OFFSET_Weapon_BaseDamagePtr            0xA8
#define OFFSET_WeaponParams_BaseDamage         0x0
#define OFFSET_Weapon_Field5F0                 0x5F0

#define OFFSET_DamageContext_DamageInfo        0x10
#define OFFSET_DamageContext_WeaponId          0x40

#define OFFSET_DamageInfo_DamageValue          0x10
#define OFFSET_DamageInfo_HitPart              0x14
#define OFFSET_DamageInfo_AttackerID           0x28
#define OFFSET_DamageInfo_Weapon               0x40

#define OFFSET_Pool_HitGameObject              0x18
#define OFFSET_Pool_HitCollider                0x20
#define OFFSET_Pool_HitLocation                0x28
#define OFFSET_Pool_RayDir                     0x34
#define OFFSET_Pool_RayDir2                    0x40
#define OFFSET_Pool_StartPos                   0x4C
#define OFFSET_Pool_Damage                     0x58
#define OFFSET_Pool_Distance                   0x5C
#define OFFSET_Pool_Flags60                    0x60
#define OFFSET_Pool_Flag64                     0x64
#define OFFSET_Pool_Flag70                     0x70
#define OFFSET_Pool_Flag71                     0x71