# NTRUNG VN — License integration and remaining-time display

This package combines the uploaded `NTRUNGVN_FULL.zip` source with the four iOS license files from `NVLicenseManager.h.zip`.

- API configured in `NVLicenseManager.m`: `https://ntrungiosvn.shopaccvt.site/license/verify.php` (as provided in the uploaded file; confirm it is deployed).
- On launch: asks for a license or re-verifies a previously entered key.
- The INFO tab shows days, hours, minutes, seconds and expiration timestamp.
- Re-verifies every 60 seconds; if invalid or expired, shows the license entry screen again.
- The INFO content is scrollable so the license card remains reachable on small screens.
- Added `NVLicenseManager.m`, `NVLicenseViewController.m` and Security framework to Makefile.

## Build

```bash
export THEOS=/home/codespace/theos
bash build.sh
```

The `.theos` directory, old `.dylib`, and previous build logs were intentionally excluded from this ZIP so they are not mistaken for the newly built output.

## Limitations

- Not compiled or tested on iOS in this environment.
- The key is cached in NSUserDefaults for subsequent online verification, which is not encrypted storage. For stronger protection, use Keychain and server-side authorization.
- License checks in a client-side tweak can be patched; this is not tamper-proof.
- The UI's expiration timestamp uses device local time, based on the server-provided Unix expiry.
