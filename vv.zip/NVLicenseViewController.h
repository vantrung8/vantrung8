#import <UIKit/UIKit.h>
@interface NVLicenseViewController : UIViewController
@property(nonatomic,copy) void (^onActivated)(NSDate *expires);
@end
