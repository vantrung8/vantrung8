#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <mach-o/dyld.h>
#import <mach/mach_time.h>
#import <os/lock.h>
#import <objc/runtime.h>
#import <pthread.h>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <dlfcn.h>
#include "Offsets.h"
#include "aimkill.h"

#pragma clang diagnostic ignored "-Wdeprecated-declarations"

struct Vec3 { float x, y, z; };
struct Quat { float x, y, z, w; };
struct ILStr { void* k; void* m; int32_t len; uint16_t c[1]; };

static inline Vec3 V3_Sub(Vec3 a, Vec3 b) { return {a.x-b.x, a.y-b.y, a.z-b.z}; }
static inline Vec3 V3_Cross(Vec3 a, Vec3 b) { return {a.y*b.z - a.z*b.y, a.z*b.x - a.x*b.z, a.x*b.y - a.y*b.x}; }
static inline float V3_Len(Vec3 v) { return sqrtf(v.x*v.x + v.y*v.y + v.z*v.z); }
static inline Vec3 V3_Norm(Vec3 v) { float l = V3_Len(v); if(l>0){v.x/=l;v.y/=l;v.z/=l;} return v; }

static Quat LookRotation(Vec3 forward, Vec3 up) {
    Vec3 f = V3_Norm(forward);
    Vec3 r = V3_Norm(V3_Cross(up, f));
    Vec3 u = V3_Cross(f, r);
    Quat q;
    q.w = sqrtf(1.0f + r.x + u.y + f.z) * 0.5f;
    if (q.w < 0.0001f) return {0,0,0,1};
    q.x = (u.z - f.y) / (4.0f * q.w);
    q.y = (f.x - r.z) / (4.0f * q.w);
    q.z = (r.y - u.x) / (4.0f * q.w);
    return q;
}

static Quat QuatSlerp(Quat a, Quat b, float t) {
    float dot = a.x*b.x + a.y*b.y + a.z*b.z + a.w*b.w;
    if (dot < 0.0f) { b.x=-b.x; b.y=-b.y; b.z=-b.z; b.w=-b.w; dot=-dot; }
    if (dot > 0.9995f) {
        Quat r = { a.x+t*(b.x-a.x), a.y+t*(b.y-a.y), a.z+t*(b.z-a.z), a.w+t*(b.w-a.w) };
        float len = sqrtf(r.x*r.x + r.y*r.y + r.z*r.z + r.w*r.w);
        if (len > 0.0001f) { r.x/=len; r.y/=len; r.z/=len; r.w/=len; }
        return r;
    }
    float theta0 = acosf(dot);
    float theta = theta0 * t;
    float s0 = cosf(theta) - dot * sinf(theta) / sinf(theta0);
    float s1 = sinf(theta) / sinf(theta0);
    return { s0*a.x+s1*b.x, s0*a.y+s1*b.y, s0*a.z+s1*b.z, s0*a.w+s1*b.w };
}

typedef NS_ENUM(NSInteger, AimBodyPart) {
    AimBodyPartHead = 0,
    AimBodyPartNeck = 1,
    AimBodyPartBody = 2
};
typedef NS_ENUM(NSInteger, AimMode) {
    AimModeAlways = 0,
    AimModeFire = 1,
    AimModeScope = 2,
    AimModeFireOrScope = 3
};

@interface ESPTarget : NSObject
@property (nonatomic, assign) CGPoint footScreen;
@property (nonatomic, assign) CGPoint headScreen;
@property (nonatomic, assign) CGPoint renderFoot;
@property (nonatomic, assign) CGPoint renderHead;
@property (nonatomic, assign) float distance;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, assign) float hpRatio;
@property (nonatomic, assign) BOOL isBot;
@property (nonatomic, assign) BOOL isKnocked;
@property (nonatomic, assign) BOOL isTarget;
@property (nonatomic, assign) BOOL hasValidPos;
@property (nonatomic, assign) BOOL isGhost;
@property (nonatomic, assign) NSTimeInterval lastSeen;
@property (nonatomic, assign) Vec3 lastWorldFoot;
@property (nonatomic, assign) Vec3 refPos;
@property (nonatomic, assign) NSTimeInterval lastMoveTime;
@property (nonatomic, assign) NSTimeInterval lastPollTime;
@property (nonatomic, assign) float velX;
@property (nonatomic, assign) float velY;
@property (nonatomic, assign) float velZ;
@end
@implementation ESPTarget
@end

static uintptr_t g_base = 0;

static BOOL g_master = YES;
static BOOL g_box = YES;
static BOOL g_line = YES;
static BOOL g_count = YES;
static BOOL g_name = YES;
static BOOL g_dist = YES;
static BOOL g_hp = YES;
static BOOL g_bot = NO;

static BOOL g_aimbot = NO;
static BOOL g_silentAim = NO;
static BOOL g_aimKill = NO;
static float g_fov = 150.0f;
static AimBodyPart g_aimBodyPart = AimBodyPartHead;
static AimMode g_aimMode = AimModeAlways;
static BOOL g_skipKnocked = YES;

static float g_maxDist = 250.0f;
static float g_uScreenW = 1920.0f;
static float g_uScreenH = 1080.0f;
static os_unfair_lock g_lock = OS_UNFAIR_LOCK_INIT;
static NSMutableDictionary<NSNumber*, ESPTarget*> *g_targets = [NSMutableDictionary dictionary];
static Quat g_lastAimQuat = {0,0,0,1};

static volatile uintptr_t g_silentMyPawn = 0;
static volatile uintptr_t g_silentTargetPawn = 0;
static volatile int g_silentBodyPart = 0;
static volatile BOOL g_silentActive = NO;
static volatile BOOL g_silentTargetValid = NO;
static volatile float g_silentTargetX = 0;
static volatile float g_silentTargetY = 0;
static volatile float g_silentTargetZ = 0;
static BOOL g_silentThreadStarted = NO;

typedef void* (*F_il2cpp_domain_get)();
typedef void** (*F_il2cpp_domain_get_assemblies)(void*, size_t*);
typedef void* (*F_il2cpp_assembly_get_image)(void*);
typedef const char* (*F_il2cpp_image_get_name)(void*);
typedef void* (*F_il2cpp_class_from_name)(void*, const char*, const char*);
typedef void (*F_il2cpp_class_init)(void*);
typedef void* (*F_il2cpp_class_get_type)(void*);
typedef void* (*F_il2cpp_type_get_object)(void*);
typedef void* (*F_il2cpp_class_get_method_from_name)(void*, const char*, int);
typedef void* (*F_il2cpp_runtime_invoke)(void*, void*, void**, void**);
typedef void* (*F_il2cpp_thread_attach)(void*);
typedef uint32_t (*F_il2cpp_gchandle_new)(void*, bool);
typedef void (*F_il2cpp_gchandle_free)(uint32_t);

static F_il2cpp_domain_get p_domain_get = nullptr;
static F_il2cpp_domain_get_assemblies p_domain_get_assemblies = nullptr;
static F_il2cpp_assembly_get_image p_asm_img = nullptr;
static F_il2cpp_image_get_name p_image_get_name = nullptr;
static F_il2cpp_class_from_name p_cls_from_name = nullptr;
static F_il2cpp_class_init p_cls_init = nullptr;
static F_il2cpp_class_get_type p_cls_get_type = nullptr;
static F_il2cpp_type_get_object p_type_get_obj = nullptr;
static F_il2cpp_class_get_method_from_name p_cls_get_method = nullptr;
static F_il2cpp_runtime_invoke p_runtime_invoke = nullptr;
static F_il2cpp_thread_attach p_thread_attach = nullptr;
static F_il2cpp_gchandle_new p_gchandle_new = nullptr;
static F_il2cpp_gchandle_free p_gchandle_free = nullptr;

typedef void* (*T_getTransform)(void*);
typedef Vec3  (*T_getPos)(void*);
typedef void* (*T_camMain)();
typedef Vec3  (*T_w2s)(void*, Vec3);
typedef int   (*T_getInt)(void*);
typedef bool  (*T_isBool)(void*);
typedef void  (*T_setAim)(void*, Quat, bool);

static T_getTransform pGetTransform = nullptr;
static T_getPos  pPos = nullptr;
static T_camMain pCam = nullptr;
static T_w2s     pW2S = nullptr;
static T_getInt  pGetW = nullptr;
static T_getInt  pGetH = nullptr;
static T_isBool  pIsDieing = nullptr;
static T_isBool  pIsDead = nullptr;
static T_isBool  pIsSighting = nullptr;
static T_setAim  pSetAim = nullptr;

static void* g_playerCls = nullptr;
static void* g_compCls = nullptr;
static void* g_goCls = nullptr;
static void* g_objCls = nullptr;
static void* g_findMethod = nullptr;
static void* g_isLocalMtd = nullptr;
static void* g_nickMtd = nullptr;
static void* g_hpMtd = nullptr;
static void* g_maxHpMtd = nullptr;
static void* g_headMtd = nullptr;
static void* g_gameObjMtd = nullptr;
static void* g_activeMtd = nullptr;
static void* g_npTypeObj = nullptr;
static void* g_fireMethod = nullptr;
static BOOL g_classesCached = NO;
static BOOL g_threadAttached = NO;

static uint32_t g_arrHandle = 0;
static void* g_cachedArr = nullptr;
static NSTimeInterval g_lastArrRefresh = 0;
static const NSTimeInterval kArrRefresh = 0.15;

static void* g_sitMethods[8] = {0};
static int g_sitMethodCount = 0;

static void u16to8(void* str, char* out, int cap) {
    out[0] = 0;
    if (!str || cap < 2) return;
    ILStr* s = (ILStr*)str;
    int n = s->len;
    if (n <= 0) return;
    if (n > cap - 1) n = cap - 1;
    int j = 0;
    for (int i = 0; i < n; i++) {
        uint16_t c = s->c[i];
        if (c < 0x80) out[j++] = (char)c;
        else if (c < 0x800) { out[j++] = (char)(0xC0|(c>>6)); out[j++] = (char)(0x80|(c&0x3F)); }
        else { out[j++] = (char)(0xE0|(c>>12)); out[j++] = (char)(0x80|((c>>6)&0x3F)); out[j++] = (char)(0x80|(c&0x3F)); }
    }
    out[j] = 0;
}

static void load_il2cpp() {
    void* handle = NULL;
    for (int i = 0; i < _dyld_image_count(); i++) {
        const char* nm = _dyld_get_image_name(i);
        if (nm && strstr(nm, "UnityFramework")) { handle = dlopen(nm, RTLD_LAZY); break; }
    }
    if (!handle) return;
    p_domain_get = (F_il2cpp_domain_get)dlsym(handle, "il2cpp_domain_get");
    p_domain_get_assemblies = (F_il2cpp_domain_get_assemblies)dlsym(handle, "il2cpp_domain_get_assemblies");
    p_asm_img = (F_il2cpp_assembly_get_image)dlsym(handle, "il2cpp_assembly_get_image");
    p_image_get_name = (F_il2cpp_image_get_name)dlsym(handle, "il2cpp_image_get_name");
    p_cls_from_name = (F_il2cpp_class_from_name)dlsym(handle, "il2cpp_class_from_name");
    p_cls_init = (F_il2cpp_class_init)dlsym(handle, "il2cpp_class_init");
    p_cls_get_type = (F_il2cpp_class_get_type)dlsym(handle, "il2cpp_class_get_type");
    p_type_get_obj = (F_il2cpp_type_get_object)dlsym(handle, "il2cpp_type_get_object");
    p_cls_get_method = (F_il2cpp_class_get_method_from_name)dlsym(handle, "il2cpp_class_get_method_from_name");
    p_runtime_invoke = (F_il2cpp_runtime_invoke)dlsym(handle, "il2cpp_runtime_invoke");
    p_thread_attach = (F_il2cpp_thread_attach)dlsym(handle, "il2cpp_thread_attach");
    p_gchandle_new = (F_il2cpp_gchandle_new)dlsym(handle, "il2cpp_gchandle_new");
    p_gchandle_free = (F_il2cpp_gchandle_free)dlsym(handle, "il2cpp_gchandle_free");
}

static void resolveFns() {
    if (!g_base) return;
    pCam = (T_camMain)(g_base + RVA_Camera_get_main);
    pW2S = (T_w2s   )(g_base + RVA_Camera_WorldToScreenPoint);
    pGetW = (T_getInt)(g_base + RVA_Camera_get_pixelWidth);
    pGetH = (T_getInt)(g_base + RVA_Camera_get_pixelHeight);
    pGetTransform = (T_getTransform)(g_base + RVA_Component_get_transform);
    pPos = (T_getPos)(g_base + RVA_Transform_get_position);
    pIsDieing = (T_isBool)(g_base + RVA_Player_IsDieing);
    pIsDead = (T_isBool)(g_base + RVA_Entity_IsDead);
    pIsSighting = (T_isBool)(g_base + RVA_Player_IsSighting);
    pSetAim = (T_setAim)(g_base + RVA_Player_SetAimRotation);
    load_il2cpp();
}

static void cacheClasses() {
    if (g_classesCached) return;
    if (!p_domain_get || !p_domain_get_assemblies || !p_cls_from_name) return;
    void* domain = p_domain_get();
    if (!domain) return;
    if (p_thread_attach) p_thread_attach(domain);
    size_t count = 0;
    void** assemblies = p_domain_get_assemblies(domain, &count);
    if (!assemblies) return;
    void* imgCore = nullptr;
    void* gameCls = nullptr;
    for (size_t i = 0; i < count; i++) {
        void* image = p_asm_img(assemblies[i]);
        if (!image) continue;
        const char* nm = p_image_get_name(image);
        if (!nm) continue;
        if (!imgCore && strstr(nm, "UnityEngine.CoreModule")) imgCore = image;
        if (!gameCls && strstr(nm, "Assembly-CSharp")) gameCls = image;
    }
    if (!imgCore || !gameCls) return;
    g_playerCls = p_cls_from_name(gameCls, "COW.GamePlay", "Player");
    g_compCls = p_cls_from_name(imgCore, "UnityEngine", "Component");
    g_goCls = p_cls_from_name(imgCore, "UnityEngine", "GameObject");
    g_objCls = p_cls_from_name(imgCore, "UnityEngine", "Object");
    if (!g_playerCls || !g_compCls || !g_goCls || !g_objCls) return;
    if (p_cls_init) p_cls_init(g_playerCls);
    g_findMethod = p_cls_get_method(g_objCls, "FindObjectsOfType", 1);
    g_isLocalMtd = p_cls_get_method(g_playerCls, "IsLocalPlayer", 0);
    g_nickMtd = p_cls_get_method(g_playerCls, "get_NickName", 0);
    g_hpMtd = p_cls_get_method(g_playerCls, "get_CurHP", 0);
    if (!g_hpMtd) g_hpMtd = p_cls_get_method(g_playerCls, "GetHp", 0);
    g_maxHpMtd = p_cls_get_method(g_playerCls, "get_MaxHP", 0);
    g_headMtd = p_cls_get_method(g_playerCls, "get_HeadBoneTransform", 0);
    if (!g_headMtd) g_headMtd = p_cls_get_method(g_playerCls, "GetHeadPositions", 0);
    g_gameObjMtd = p_cls_get_method(g_compCls, "get_gameObject", 0);
    g_activeMtd = p_cls_get_method(g_goCls, "get_activeInHierarchy", 0);
    void* npType = p_cls_get_type(g_playerCls);
    if (npType) g_npTypeObj = p_type_get_obj(npType);
    const char* fireNames[] = {"get_IsFiringFromPRI","IsFiringFromPRI","get_IsFiring","IsFiring","get_IsFire","IsFire","get_IsAttack","IsAttack","get_IsShooting","IsShooting"};
    for (int k = 0; k < 10; k++) {
        void* m = p_cls_get_method(g_playerCls, fireNames[k], 0);
        if (m) { g_fireMethod = m; break; }
    }
    const char* sitNames[] = {"get_IsCrouching","IsCrouching","get_IsProne","IsProne","get_IsSitting","IsSitting","get_IsLie","IsLie"};
    g_sitMethodCount = 0;
    for (int k = 0; k < 8; k++) {
        void* m = p_cls_get_method(g_playerCls, sitNames[k], 0);
        if (m) g_sitMethods[g_sitMethodCount++] = m;
    }
    if (g_findMethod && g_npTypeObj) g_classesCached = YES;
}

static void clearTargets() {
    os_unfair_lock_lock(&g_lock);
    g_targets = [NSMutableDictionary dictionary];
    os_unfair_lock_unlock(&g_lock);
}

static BOOL isPlayerSittingOrLying(void* player, Vec3 footWS, Vec3 headWS) {
    for (int i = 0; i < g_sitMethodCount; i++) {
        void* exc = nullptr;
        void* ret = p_runtime_invoke(g_sitMethods[i], player, NULL, &exc);
        if (!exc && ret && *(bool*)((uintptr_t)ret + 0x10)) return YES;
    }
    if (g_sitMethodCount == 0) {
        float hf = headWS.y - footWS.y;
        if (hf > 0.1f && hf < 1.2f) return YES;
    }
    return NO;
}

static void ApplySilentAimRaw(uintptr_t hitObj, Vec3 targetPos) {
    if (!hitObj) return;
    if (hitObj < 0x100000000ULL || hitObj > 0x7FFFFFFFFFFFULL) return;
    if (targetPos.x == 0 && targetPos.y == 0 && targetPos.z == 0) return;
    if (isnan(targetPos.x) || isnan(targetPos.y) || isnan(targetPos.z)) return;

    Vec3 origin = *(Vec3*)(hitObj + 0x4C);
    if (isnan(origin.x) || isnan(origin.y) || isnan(origin.z)) return;
    if (isinf(origin.x) || isinf(origin.y) || isinf(origin.z)) return;
    if (fabsf(origin.x) > 10000.0f || fabsf(origin.y) > 10000.0f || fabsf(origin.z) > 10000.0f) return;
    if (origin.x == 0 && origin.y == 0 && origin.z == 0) return;

    Vec3 dir = V3_Sub(targetPos, origin);
    float len = V3_Len(dir);
    if (len < 0.001f || isnan(len) || isinf(len)) return;

    Vec3 origDir = *(Vec3*)(hitObj + 0x40);
    float origLen = V3_Len(origDir);
    if (origLen < 0.001f || isnan(origLen) || isinf(origLen)) origLen = len;
    float k = origLen / len;

    Vec3 newDir = { dir.x * k, dir.y * k, dir.z * k };
    if (isnan(newDir.x) || isnan(newDir.y) || isnan(newDir.z)) return;

    *(Vec3*)(hitObj + 0x40) = newDir;
    *(Vec3*)(hitObj + 0x28) = targetPos;
}

static Vec3 GetLiveAimWorld(uintptr_t player, int bodyPart) {
    Vec3 result = {0,0,0};
    if (!player || !g_headMtd || !pGetTransform || !pPos || !p_runtime_invoke) return result;
    void* excH = nullptr;
    void* retH = p_runtime_invoke(g_headMtd, (void*)player, NULL, &excH);
    if (excH || !retH) return result;
    void* headTrans = pGetTransform(retH);
    if (!headTrans) return result;
    Vec3 headWS = pPos(headTrans);
    if (headWS.x == 0 && headWS.y == 0 && headWS.z == 0) return result;
    if (bodyPart == 0) {
        result = headWS;
        result.y += 0.05f;
    } else if (bodyPart == 1) {
        result = headWS;
        result.y -= 0.20f;
    } else {
        result = headWS;
        result.y -= 0.40f;
    }
    return result;
}

static void* silentThreadFunc(void* arg) {
    if (p_domain_get && p_thread_attach) {
        void* domain = p_domain_get();
        if (domain) p_thread_attach(domain);
    }

    uintptr_t lastHitObj = 0;
    Vec3 lastBulletOrigin = {0,0,0};
    uintptr_t lastCachedHitObj = 0;
    uint64_t lastHitObjTimeNs = 0;
    mach_timebase_info_data_t tb;
    mach_timebase_info(&tb);

    Vec3 liveTarget = {0,0,0};
    BOOL liveValid = NO;

    while (1) {
        @autoreleasepool {
            if (!g_silentAim || !g_silentActive || !g_silentTargetValid) {
                lastHitObj = 0;
                lastBulletOrigin = (Vec3){0,0,0};
                lastCachedHitObj = 0;
                liveTarget = (Vec3){0,0,0};
                liveValid = NO;
                usleep(2000);
                continue;
            }

            uintptr_t mp = g_silentMyPawn;
            if (mp < 0x100000000ULL || mp > 0x7FFFFFFFFFFFULL) { usleep(100); continue; }
            if (!g_silentActive) { usleep(100); continue; }

            uintptr_t lo = *(uintptr_t*)(mp + 0xE50);
            if (lo < 0x100000000ULL || lo > 0x7FFFFFFFFFFFULL) lo = 0;
            if (!g_silentActive) { usleep(100); continue; }

            uintptr_t ho = 0;
            uint64_t nowNs = mach_absolute_time();

            if (lo) {
                ho = lo;
                lastCachedHitObj = lo;
                lastHitObjTimeNs = nowNs;
            } else if (lastCachedHitObj) {
                uint64_t elapsedNs = nowNs - lastHitObjTimeNs;
                uint64_t elapsedUs = (elapsedNs * tb.numer / tb.denom) / 1000;
                if (elapsedUs < 50000) ho = lastCachedHitObj;
            }

            if (!ho) { usleep(100); continue; }

            uintptr_t targetPawn = g_silentTargetPawn;
            Vec3 fresh = GetLiveAimWorld(targetPawn, g_silentBodyPart);
            if (fresh.x != 0 || fresh.y != 0 || fresh.z != 0) {
                liveTarget = fresh;
                liveValid = YES;
            }
            Vec3 targetPos;
            if (liveValid) {
                targetPos = liveTarget;
            } else {
                targetPos.x = g_silentTargetX;
                targetPos.y = g_silentTargetY;
                targetPos.z = g_silentTargetZ;
            }
            if (targetPos.x == 0 && targetPos.y == 0 && targetPos.z == 0) { usleep(50); continue; }

            Vec3 bo = *(Vec3*)(ho + 0x4C);
            if (isnan(bo.x) || isnan(bo.y) || isnan(bo.z)) { usleep(100); continue; }

            BOOL bulletChanged = (ho != lastHitObj) ||
                (fabsf(bo.x - lastBulletOrigin.x) > 0.0005f) ||
                (fabsf(bo.y - lastBulletOrigin.y) > 0.0005f) ||
                (fabsf(bo.z - lastBulletOrigin.z) > 0.0005f);

            if (bulletChanged) {
                lastHitObj = ho;
                lastBulletOrigin = bo;
                uint64_t start = mach_absolute_time();
                uint64_t elapsedUs;
                int guard = 0;
                do {
                    ApplySilentAimRaw(ho, targetPos);
                    guard++;
                    if ((guard & 3) == 0) {
                        Vec3 f2 = GetLiveAimWorld(targetPawn, g_silentBodyPart);
                        if (f2.x != 0 || f2.y != 0 || f2.z != 0) {
                            targetPos = f2;
                            liveTarget = f2;
                            liveValid = YES;
                        }
                    }
                    uint64_t t = mach_absolute_time() - start;
                    elapsedUs = (t * tb.numer / tb.denom) / 1000;
                    if (!g_silentActive) break;
                    uintptr_t cur = *(uintptr_t*)(mp + 0xE50);
                    if (cur >= 0x100000000ULL && cur <= 0x7FFFFFFFFFFFULL && cur != ho) break;
                } while (elapsedUs < 10000 && guard < 100000);
            } else {
                ApplySilentAimRaw(ho, targetPos);
                usleep(30);
            }
        }
    }
    return NULL;
}

static void StartSilentAimThread() {
    if (g_silentThreadStarted) return;
    g_silentThreadStarted = YES;
    pthread_t th;
    pthread_create(&th, NULL, silentThreadFunc, NULL);
    pthread_detach(th);
}

static void pollTick() {
    @try {
        if (!g_master || !g_base || !pCam) {
            g_silentActive = NO;
            g_silentTargetValid = NO;
            clearTargets();
            return;
        }
        if (!g_classesCached) {
            cacheClasses();
            if (!g_classesCached) {
                g_silentActive = NO;
                g_silentTargetValid = NO;
                clearTargets();
                return;
            }
        }

        void* cam = pCam();
        if (!cam) {
            g_silentActive = NO;
            g_silentTargetValid = NO;
            clearTargets();
            return;
        }
        if (!pW2S || !pGetTransform || !pPos || !pGetW || !pGetH) {
            g_silentActive = NO;
            g_silentTargetValid = NO;
            clearTargets();
            return;
        }

        g_uScreenW = (float)pGetW(cam);
        g_uScreenH = (float)pGetH(cam);

        Vec3 camPos = {0,0,0};
        void* camTrans = pGetTransform(cam);
        if (camTrans) camPos = pPos(camTrans);

        if (p_domain_get && p_thread_attach && !g_threadAttached) {
            void* d = p_domain_get();
            if (d) { p_thread_attach(d); g_threadAttached = YES; }
        }

        NSTimeInterval now = [NSDate timeIntervalSinceReferenceDate];

        if (!g_cachedArr || (now - g_lastArrRefresh) > kArrRefresh) {
            if (g_arrHandle && p_gchandle_free) { p_gchandle_free(g_arrHandle); g_arrHandle = 0; }
            void* params[1] = { g_npTypeObj };
            void* exc = nullptr;
            void* arr = p_runtime_invoke(g_findMethod, NULL, params, &exc);
            if (!exc && arr) {
                g_cachedArr = arr;
                if (p_gchandle_new) g_arrHandle = p_gchandle_new(arr, true);
            } else {
                g_cachedArr = nullptr;
            }
            g_lastArrRefresh = now;
        }
        void* arr = g_cachedArr;
        if (!arr) {
            g_silentActive = NO;
            g_silentTargetValid = NO;
            clearTargets();
            return;
        }

        uintptr_t len = *(uintptr_t*)((uintptr_t)arr + 0x18);
        if (len == 0 || len > 300) {
            g_silentActive = NO;
            g_silentTargetValid = NO;
            clearTargets();
            return;
        }
        void** data = (void**)((uintptr_t)arr + 0x20);

        uintptr_t localPlayerPtr = 0;
        if (g_isLocalMtd) {
            for (uintptr_t j = 0; j < len; j++) {
                void* player = data[j];
                if (!player) continue;
                void* excL = nullptr;
                void* retL = p_runtime_invoke(g_isLocalMtd, player, NULL, &excL);
                if (!excL && retL && *(bool*)((uintptr_t)retL + 0x10)) {
                    localPlayerPtr = (uintptr_t)player;
                    break;
                }
            }
        }

        if (!localPlayerPtr) {
            if (g_arrHandle && p_gchandle_free) { p_gchandle_free(g_arrHandle); g_arrHandle = 0; }
            g_cachedArr = nullptr;
            g_lastArrRefresh = 0;
            g_silentActive = NO;
            g_silentTargetValid = NO;
            g_silentMyPawn = 0;
            g_silentTargetPawn = 0;
            clearTargets();
            return;
        }

        BOOL globalShouldAim = NO;
        if (g_aimbot && localPlayerPtr) {
            BOOL isLocalSighting = (pIsSighting ? pIsSighting((void*)localPlayerPtr) : NO);
            BOOL isLocalFiring = NO;
            if (g_fireMethod) {
                void* excF = nullptr;
                void* retF = p_runtime_invoke(g_fireMethod, (void*)localPlayerPtr, NULL, &excF);
                if (!excF && retF) isLocalFiring = *(bool*)((uintptr_t)retF + 0x10);
            }
            switch (g_aimMode) {
                case AimModeAlways: globalShouldAim = YES; break;
                case AimModeFire: globalShouldAim = isLocalFiring; break;
                case AimModeScope: globalShouldAim = isLocalSighting; break;
                case AimModeFireOrScope: globalShouldAim = (isLocalFiring || isLocalSighting); break;
            }
            if (!g_fireMethod) {
                if (g_aimMode == AimModeFire) globalShouldAim = YES;
                if (g_aimMode == AimModeFireOrScope) globalShouldAim = isLocalSighting;
            }
        }

        void* closestEnemy = nullptr;
        float minScreenDist = 9999.0f;
        Vec3 closestAimWorld = {0,0,0};
        float closestVelX = 0;
        float closestVelZ = 0;
        CGPoint screenCenter = CGPointMake(g_uScreenW / 2.0f, g_uScreenH / 2.0f);
        NSMutableDictionary *newTargets = [NSMutableDictionary dictionary];

        for (uintptr_t j = 0; j < len; j++) {
            void* player = data[j];
            if (!player) continue;
            if ((uintptr_t)player == localPlayerPtr) continue;

            uint32_t pID = *(uint32_t*)((uintptr_t)player + OFFSET_Player_PlayerID);
            if (pID == 0) continue;

            if (pIsDead && pIsDead(player)) continue;

            BOOL isKnocked = false;
            if (pIsDieing && pIsDieing(player)) isKnocked = true;

            int hp = -1, maxHp = -1;
            if (g_hpMtd) {
                void* excH = nullptr;
                void* retH = p_runtime_invoke(g_hpMtd, player, NULL, &excH);
                if (!excH && retH) hp = *(int*)((uintptr_t)retH + 0x10);
            }
            if (g_maxHpMtd) {
                void* excM = nullptr;
                void* retM = p_runtime_invoke(g_maxHpMtd, player, NULL, &excM);
                if (!excM && retM) maxHp = *(int*)((uintptr_t)retM + 0x10);
            }
            if (maxHp <= 0) maxHp = 100;
            if (hp < 0) hp = maxHp;
            if (hp == 0) continue;
            if (hp > maxHp * 10) hp = maxHp;

            BOOL isBot = *(bool*)((uintptr_t)player + OFFSET_Player_IsClientBot);
            if (isBot && !g_bot) continue;

            NSNumber *key = @((uintptr_t)player);
            ESPTarget *t = g_targets[key];

            char tName[64] = {0};
            if (t && t.name.length > 0) {
                strncpy(tName, [t.name UTF8String], 63);
            } else {
                if (g_nickMtd) {
                    void* excN = nullptr;
                    void* retN = p_runtime_invoke(g_nickMtd, player, NULL, &excN);
                    if (!excN && retN) u16to8(retN, tName, 64);
                }
                if (tName[0] == 0) {
                    if (isBot) strcpy(tName, "Bot");
                    else continue;
                }
            }

            void* trans = pGetTransform(player);
            if (!trans) continue;
            Vec3 footWS = pPos(trans);
            if (footWS.x == 0 && footWS.y == 0 && footWS.z == 0) continue;
            if (fabsf(footWS.y) > 1000.0f) continue;

            Vec3 headWS = {0,0,0};
            if (g_headMtd) {
                void* excHH = nullptr;
                void* retHH = p_runtime_invoke(g_headMtd, player, NULL, &excHH);
                if (!excHH && retHH) {
                    void* headTrans = pGetTransform(retHH);
                    if (headTrans) headWS = pPos(headTrans);
                }
            }
            if (headWS.x == 0 && headWS.y == 0 && headWS.z == 0) {
                headWS = footWS;
                headWS.y += 1.6f;
            }
            if (isKnocked) headWS.y = footWS.y + 0.6f;

            if (!t) {
                t = [[ESPTarget alloc] init];
                t.refPos = footWS;
                t.lastMoveTime = now;
                t.lastPollTime = now;
                t.lastWorldFoot = footWS;
                t.isGhost = NO;
                g_targets[key] = t;
            } else {
                float distFromRef = V3_Len(V3_Sub(footWS, t.refPos));
                if (distFromRef > 1.0f) {
                    t.refPos = footWS;
                    t.lastMoveTime = now;
                }
                float dt = now - t.lastPollTime;
                if (dt > 0.005f && dt < 0.5f) {
                    t.velX = (footWS.x - t.lastWorldFoot.x) / dt;
                    t.velY = (footWS.y - t.lastWorldFoot.y) / dt;
                    t.velZ = (footWS.z - t.lastWorldFoot.z) / dt;
                }
                t.lastWorldFoot = footWS;
                t.lastPollTime = now;
            }

            BOOL isSitting = isPlayerSittingOrLying(player, footWS, headWS);
            BOOL isGhost = (!isSitting && !isBot && (now - t.lastMoveTime > 5.0));
            if (isGhost) {
                t.isGhost = YES;
                t.lastSeen = now;
                newTargets[key] = t;
                continue;
            }
            t.isGhost = NO;
            t.lastSeen = now;

            Vec3 footSp = pW2S(cam, footWS);
            if (isnan(footSp.x) || isnan(footSp.y) || isinf(footSp.x) || isinf(footSp.y)) {
                newTargets[key] = t;
                continue;
            }

            float dx = footWS.x - camPos.x;
            float dy = footWS.y - camPos.y;
            float dz = footWS.z - camPos.z;
            float dist3d = sqrtf(dx*dx + dy*dy + dz*dz);
            if (dist3d > g_maxDist) {
                newTargets[key] = t;
                continue;
            }

            t.name = [NSString stringWithUTF8String:tName];
            t.hpRatio = (float)hp / (float)maxHp;
            t.isBot = isBot;
            t.isKnocked = isKnocked;
            t.distance = dist3d;
            t.isTarget = NO;
            t.hasValidPos = NO;

            if (footSp.z <= 0.1f) {
                newTargets[key] = t;
                continue;
            }

            Vec3 headSp = pW2S(cam, headWS);
            if (isnan(headSp.x) || isnan(headSp.y) || isinf(headSp.x) || isinf(headSp.y)) {
                newTargets[key] = t;
                continue;
            }

            Vec3 aimWorld;
            if (g_aimBodyPart == AimBodyPartHead) {
                aimWorld = headWS;
                aimWorld.y += 0.05f;
            } else if (g_aimBodyPart == AimBodyPartNeck) {
                aimWorld = headWS;
                aimWorld.y -= 0.20f;
            } else {
                aimWorld = headWS;
                aimWorld.y -= 0.40f;
            }

            Vec3 aimSp = pW2S(cam, aimWorld);
            float distToCenter = 9999.0f;
            if (!isnan(aimSp.x) && !isnan(aimSp.y)) {
                distToCenter = sqrtf((aimSp.x - screenCenter.x)*(aimSp.x - screenCenter.x) + (aimSp.y - screenCenter.y)*(aimSp.y - screenCenter.y));
            }

            BOOL canAim = YES;
            if (isKnocked && g_skipKnocked) canAim = NO;

            if ((g_aimbot || g_silentAim) && canAim && distToCenter <= g_fov && distToCenter < minScreenDist) {
                minScreenDist = distToCenter;
                closestEnemy = player;
                closestAimWorld = aimWorld;
                closestVelX = t.velX;
                closestVelZ = t.velZ;
                t.isTarget = YES;
            }

            t.footScreen = CGPointMake(footSp.x, footSp.y);
            t.headScreen = CGPointMake(headSp.x, headSp.y);
            t.hasValidPos = YES;
            newTargets[key] = t;
        }

        if (g_silentAim && closestEnemy && localPlayerPtr) {
            g_silentMyPawn = localPlayerPtr;
            g_silentTargetPawn = (uintptr_t)closestEnemy;
            g_silentBodyPart = (int)g_aimBodyPart;
            g_silentTargetX = closestAimWorld.x;
            g_silentTargetY = closestAimWorld.y;
            g_silentTargetZ = closestAimWorld.z;
            g_silentTargetValid = YES;
            g_silentActive = YES;
        } else {
            g_silentActive = NO;
            g_silentTargetValid = NO;
            g_silentMyPawn = 0;
            g_silentTargetPawn = 0;
        }

        if (g_aimbot && closestEnemy && localPlayerPtr && globalShouldAim) {
            float distance = V3_Len(V3_Sub(closestAimWorld, camPos));
            float leadTime = 0.05f + distance * 0.0003f;
            Vec3 leadAim = closestAimWorld;
            leadAim.x += closestVelX * leadTime;
            leadAim.z += closestVelZ * leadTime;
            Vec3 dir = V3_Sub(leadAim, camPos);
            Quat targetQuat = LookRotation(dir, {0,1,0});
            float speed = sqrtf(closestVelX*closestVelX + closestVelZ*closestVelZ);
            float slerpFactor = (speed > 1.0f) ? 1.0f : 0.95f;
            g_lastAimQuat = QuatSlerp(g_lastAimQuat, targetQuat, slerpFactor);
            if (pSetAim) pSetAim((void*)localPlayerPtr, g_lastAimQuat, true);
        }

        if (g_aimKill && closestEnemy && localPlayerPtr) {
            Vec3 localHead = {0, 0, 0};
            void* localTrans = pGetTransform((void*)localPlayerPtr);
            if (localTrans) {
                localHead = pPos(localTrans);
                localHead.y += 1.6f;
            }
            AimKill_Vec3 lh = {localHead.x, localHead.y, localHead.z};
            AimKill_Vec3 eh = {closestAimWorld.x, closestAimWorld.y, closestAimWorld.z};
            AimKill::Run(g_base, (void*)localPlayerPtr, closestEnemy, lh, eh);
        }

        NSTimeInterval cutoff = now - 0.35;
        NSMutableArray *deadKeys = [NSMutableArray array];
        for (NSNumber *k in newTargets.allKeys) {
            ESPTarget *t = newTargets[k];
            if (t.lastSeen < cutoff) [deadKeys addObject:k];
        }
        if (deadKeys.count > 0) [newTargets removeObjectsForKeys:deadKeys];

        os_unfair_lock_lock(&g_lock);
        g_targets = newTargets;
        os_unfair_lock_unlock(&g_lock);
    } @catch (NSException *e) {
        g_silentActive = NO;
        g_silentTargetValid = NO;
        clearTargets();
    }
}

@interface ESPLayer : UIView
@property (nonatomic, strong) NSDictionary<NSNumber*, ESPTarget*> *targets;
@property (nonatomic, strong) NSString *countText;
@property (nonatomic, assign) BOOL showLine;
@property (nonatomic, assign) BOOL showBox;
@property (nonatomic, assign) BOOL showName;
@property (nonatomic, assign) BOOL showDist;
@property (nonatomic, assign) BOOL showHp;
@property (nonatomic, assign) BOOL showAimFov;
@end

@implementation ESPLayer
- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        self.userInteractionEnabled = NO;
        self.opaque = NO;
    }
    return self;
}

- (void)drawRect:(CGRect)rect {
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    if (!ctx) return;
    float scaleX = rect.size.width / g_uScreenW;
    float scaleY = rect.size.height / g_uScreenH;
    os_unfair_lock_lock(&g_lock);
    NSDictionary *targets = self.targets;
    os_unfair_lock_unlock(&g_lock);
    if (targets.count == 0) return;

    if (self.showAimFov) {
        CGPoint center = CGPointMake(rect.size.width/2, rect.size.height/2);
        CGContextSetStrokeColorWithColor(ctx, [UIColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:0.5].CGColor);
        CGContextSetLineWidth(ctx, 1.0);
        CGContextStrokeEllipseInRect(ctx, CGRectMake(center.x - g_fov, center.y - g_fov, g_fov*2, g_fov*2));
    }

    if (self.countText.length > 0) {
        UIFont *countFont = [UIFont boldSystemFontOfSize:20];
        NSDictionary *attrs = @{ NSFontAttributeName: countFont, NSForegroundColorAttributeName: [UIColor whiteColor] };
        CGSize sz = [self.countText sizeWithAttributes:attrs];
        CGPoint pos = CGPointMake((rect.size.width - sz.width) / 2.0, 40.0);
        [self.countText drawAtPoint:pos withAttributes:attrs];
    }

    for (NSNumber *key in targets.allKeys) {
        ESPTarget *t = targets[key];
        if (t.isGhost) continue;
        if (!t.hasValidPos) continue;

        CGFloat newFX = t.renderFoot.x + (t.footScreen.x - t.renderFoot.x) * 0.8f;
        CGFloat newFY = t.renderFoot.y + (t.footScreen.y - t.renderFoot.y) * 0.8f;
        CGFloat newHX = t.renderHead.x + (t.headScreen.x - t.renderHead.x) * 0.8f;
        CGFloat newHY = t.renderHead.y + (t.headScreen.y - t.renderHead.y) * 0.8f;
        t.renderFoot = CGPointMake(newFX, newFY);
        t.renderHead = CGPointMake(newHX, newHY);

        float fx = newFX * scaleX;
        float fy = rect.size.height - (newFY * scaleY);
        float hx = newHX * scaleX;
        float hy = rect.size.height - (newHY * scaleY);
        (void)hx;

        if (fx < -200 || fx > rect.size.width + 200) continue;
        if (fy < -200 || fy > rect.size.height + 200) continue;

        float fullH = fabsf(fy - hy);
        if (fullH < 2.0f) continue;
        if (t.isKnocked) fullH *= 0.9f;

        float boxH = fullH * 0.85f;
        float boxW = boxH * 0.65f;
        float boxY = fy - boxH;
        CGRect boxRect = CGRectMake(fx - boxW/2, boxY, boxW, boxH);

        UIColor *color;
        if (t.isBot) color = [UIColor yellowColor];
        else color = [UIColor colorWithRed:0.0 green:0.96 blue:1.0 alpha:1.0];

        if (self.showLine) {
            CGContextSetStrokeColorWithColor(ctx, color.CGColor);
            CGContextSetLineWidth(ctx, 0.8);
            CGContextMoveToPoint(ctx, rect.size.width / 2.0, 0);
            CGContextAddLineToPoint(ctx, fx, boxY);
            CGContextStrokePath(ctx);
        }
        if (self.showBox) {
            CGContextSetStrokeColorWithColor(ctx, color.CGColor);
            CGContextSetLineWidth(ctx, 0.8);
            CGContextStrokeRect(ctx, boxRect);
        }
        if (self.showName) {
            UIFont *nameFont = [UIFont boldSystemFontOfSize:7];
            NSDictionary *attrs = @{ NSFontAttributeName: nameFont, NSForegroundColorAttributeName: [UIColor whiteColor] };
            CGSize nameSize = [t.name sizeWithAttributes:attrs];
            CGFloat nameX = boxRect.origin.x + (boxRect.size.width - nameSize.width) / 2.0;
            CGFloat nameY = boxY - nameSize.height - 2;
            [t.name drawAtPoint:CGPointMake(nameX, nameY) withAttributes:attrs];
        }
        if (self.showDist) {
            NSString *distStr = [NSString stringWithFormat:@"[%dM]", (int)t.distance];
            UIFont *distFont = [UIFont boldSystemFontOfSize:7];
            NSDictionary *attrs = @{ NSFontAttributeName: distFont, NSForegroundColorAttributeName: [UIColor whiteColor] };
            CGSize distSize = [distStr sizeWithAttributes:attrs];
            CGFloat distX = boxRect.origin.x + (boxRect.size.width - distSize.width) / 2.0;
            CGFloat distY = boxY - distSize.height - 2;
            if (self.showName) {
                UIFont *nameFont = [UIFont boldSystemFontOfSize:7];
                NSDictionary *nameAttrs = @{NSFontAttributeName: nameFont};
                CGSize nameSize = [t.name sizeWithAttributes:nameAttrs];
                distY -= nameSize.height + 1;
            }
            [distStr drawAtPoint:CGPointMake(distX, distY) withAttributes:attrs];
        }
        if (self.showHp) {
            float barX = boxRect.origin.x - 4;
            float barW = 1.5f;
            float barH = boxRect.size.height;
            CGContextSetFillColorWithColor(ctx, [UIColor colorWithWhite:0.15 alpha:0.8].CGColor);
            CGContextFillRect(ctx, CGRectMake(barX, boxY, barW, barH));
            UIColor *hpColor;
            if (t.hpRatio > 0.5f) hpColor = [UIColor greenColor];
            else if (t.hpRatio > 0.25f) hpColor = [UIColor yellowColor];
            else hpColor = [UIColor redColor];
            CGContextSetFillColorWithColor(ctx, hpColor.CGColor);
            CGContextFillRect(ctx, CGRectMake(barX, boxY + (barH * (1.0f - t.hpRatio)), barW, barH * t.hpRatio));
        }
    }
}
@end

@interface ModMenuWindow : UIWindow
@property(nonatomic,strong) UIView *menuView;
@property(nonatomic,strong) UIButton *floatingBtn;
@property(nonatomic,strong) UISegmentedControl *tabControl;
@property(nonatomic,strong) UIScrollView *espView,*aimView;
@property(nonatomic,strong) UIView *infoView;
@property(nonatomic,strong) UILabel *licenseRemainingLabel;
@property(nonatomic,strong) UILabel *licenseExpiryLabel;
@property(nonatomic,strong) UIView *licenseOverlay;
@property(nonatomic,strong) NVLicenseViewController *licenseController;
@property(nonatomic,strong) NSDate *licenseExpiry;
@property(nonatomic,assign) BOOL licenseValid;
@property(nonatomic,assign) BOOL licenseChecking;
- (void)beginLicenseValidation;
- (void)refreshLicenseStatus;
@property(nonatomic,strong) ESPLayer *espLayer;
@property(nonatomic,strong) UIButton *checkESP,*espBoxBtn,*espLineBtn,*espNameBtn,*espDistBtn,*espHpBtn,*espCountBtn,*espBotBtn;
@property(nonatomic,strong) UIButton *aimbotBtn,*silentAimBtn,*aimKillBtn,*skipKnockedBtn;
@property(nonatomic,strong) UISegmentedControl *bodyPartSegment,*aimModeSegment;
@property(nonatomic,strong) UISlider *fovSlider;
- (void)tickESP;
@end

@implementation ModMenuWindow
static UIColor *NVColor(unsigned rgb) { return [UIColor colorWithRed:((rgb>>16)&255)/255.0 green:((rgb>>8)&255)/255.0 blue:(rgb&255)/255.0 alpha:1]; }
- (UILabel *)label:(NSString *)s frame:(CGRect)f size:(CGFloat)z bold:(BOOL)b color:(UIColor *)c parent:(UIView *)v {
    UILabel *l=[[UILabel alloc]initWithFrame:f]; l.text=s; l.textColor=c;
    l.font=b?[UIFont systemFontOfSize:z weight:UIFontWeightSemibold]:[UIFont systemFontOfSize:z];
    l.adjustsFontSizeToFitWidth=YES; [v addSubview:l]; return l;
}
- (UIView *)panel:(CGRect)r parent:(UIView *)v {
    UIView *p=[[UIView alloc]initWithFrame:r]; p.backgroundColor=NVColor(0x151D2B);
    p.layer.cornerRadius=12; p.layer.borderWidth=1; p.layer.borderColor=NVColor(0x273346).CGColor;
    [v addSubview:p]; return p;
}
- (void)loadLogo:(UIImageView *)iv {
    NSURL *url=[NSURL URLWithString:@"https://cdn.upanhlaylink.com/i/hMrZMgDK.png"];
    [[[NSURLSession sharedSession] dataTaskWithURL:url completionHandler:^(NSData *d,NSURLResponse *r,NSError *e) {
        if(e || !d)return; UIImage *im=[UIImage imageWithData:d];
        if(im) dispatch_async(dispatch_get_main_queue(),^{ iv.image=im; });
    }] resume];
}
- (instancetype)initWithFrame:(CGRect)frame {
    if(!(self=[super initWithFrame:frame]))return nil;
    self.windowLevel=UIWindowLevelAlert+100; self.backgroundColor=UIColor.clearColor;
    self.rootViewController=[UIViewController new]; self.rootViewController.view.backgroundColor=UIColor.clearColor;
    CGFloat sw=frame.size.width,sh=frame.size.height,mw=MIN(370,sw-24),mh=MIN(455,sh-35);
    self.espLayer=[[ESPLayer alloc]initWithFrame:CGRectMake(0,0,sw,sh)]; self.espLayer.hidden=YES;
    [self.rootViewController.view addSubview:self.espLayer];
    self.menuView=[[UIView alloc]initWithFrame:CGRectMake((sw-mw)/2,(sh-mh)/2,mw,mh)];
    self.menuView.backgroundColor=NVColor(0x0C121E); self.menuView.layer.cornerRadius=20;
    self.menuView.layer.borderWidth=1; self.menuView.layer.borderColor=NVColor(0x34485F).CGColor;
    self.menuView.layer.shadowColor=UIColor.blackColor.CGColor; self.menuView.layer.shadowOpacity=.55;
    self.menuView.layer.shadowRadius=24; [self.rootViewController.view addSubview:self.menuView];
    UIView *header=[[UIView alloc]initWithFrame:CGRectMake(0,0,mw,79)]; [self.menuView addSubview:header];
    UIImageView *logo=[[UIImageView alloc]initWithFrame:CGRectMake(18,17,42,42)];
    logo.contentMode=UIViewContentModeScaleAspectFill; logo.clipsToBounds=YES;
    logo.layer.cornerRadius=12; logo.backgroundColor=NVColor(0x1B3448);
    [header addSubview:logo]; [self loadLogo:logo];
    [self label:@"NTRUNG VN" frame:CGRectMake(71,16,mw-125,25) size:19 bold:YES color:UIColor.whiteColor parent:header];
    [self label:@"PREMIUM CONTROL PANEL" frame:CGRectMake(72,41,mw-125,16) size:10 bold:YES color:NVColor(0x53D5E9) parent:header];
    UIButton *close=[UIButton buttonWithType:UIButtonTypeSystem]; close.frame=CGRectMake(mw-48,20,30,30);
    close.layer.cornerRadius=10; close.backgroundColor=NVColor(0x202B3A);
    [close setTitle:@"×" forState:UIControlStateNormal]; [close setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    close.titleLabel.font=[UIFont systemFontOfSize:23];
    [close addTarget:self action:@selector(closeMenu) forControlEvents:UIControlEventTouchUpInside]; [header addSubview:close];
    UIPanGestureRecognizer *pan=[[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(handlePan:)];
    [header addGestureRecognizer:pan];
    UIView *line=[[UIView alloc]initWithFrame:CGRectMake(16,77,mw-32,1)];
    line.backgroundColor=NVColor(0x283548); [self.menuView addSubview:line];
    self.tabControl=[[UISegmentedControl alloc]initWithItems:@[@"ESP",@"AIMBOT",@"INFO"]];
    self.tabControl.frame=CGRectMake(16,91,mw-32,35); self.tabControl.selectedSegmentIndex=0;
    self.tabControl.backgroundColor=NVColor(0x182333); self.tabControl.selectedSegmentTintColor=NVColor(0x29B8D4);
    [self.tabControl setTitleTextAttributes:@{NSForegroundColorAttributeName:UIColor.whiteColor,NSFontAttributeName:[UIFont boldSystemFontOfSize:11]} forState:UIControlStateNormal];
    [self.tabControl addTarget:self action:@selector(tabChanged:) forControlEvents:UIControlEventValueChanged];
    [self.menuView addSubview:self.tabControl];
    CGRect content=CGRectMake(16,138,mw-32,mh-151); CGFloat w=content.size.width,col=(w-12)/2;
    self.espView=[[UIScrollView alloc]initWithFrame:content]; self.espView.contentSize=CGSizeMake(w,285);
    [self.menuView addSubview:self.espView];
    self.aimView=[[UIScrollView alloc]initWithFrame:content]; self.aimView.contentSize=CGSizeMake(w,335);
    self.aimView.hidden=YES; [self.menuView addSubview:self.aimView];
    self.infoView=[[UIScrollView alloc]initWithFrame:content]; ((UIScrollView *)self.infoView).contentSize=CGSizeMake(w,380); self.infoView.hidden=YES;
    [self.menuView addSubview:self.infoView];
    [self label:@"VISUAL SETTINGS" frame:CGRectMake(3,0,w,18) size:11 bold:YES color:NVColor(0x8A9BB3) parent:self.espView];
    self.checkESP=[self makeCheckBox:self.espView x:0 y:25 w:w t:@"Enable ESP" a:@selector(onESPTapped)];
    self.espBoxBtn=[self makeCheckBox:self.espView x:0 y:73 w:col t:@"Box" a:@selector(onEspBoxTapped)];
    self.espLineBtn=[self makeCheckBox:self.espView x:col+12 y:73 w:col t:@"Line" a:@selector(onEspLineTapped)];
    self.espNameBtn=[self makeCheckBox:self.espView x:0 y:121 w:col t:@"Name" a:@selector(onEspNameTapped)];
    self.espDistBtn=[self makeCheckBox:self.espView x:col+12 y:121 w:col t:@"Distance" a:@selector(onEspDistTapped)];
    self.espHpBtn=[self makeCheckBox:self.espView x:0 y:169 w:col t:@"Health" a:@selector(onEspHpTapped)];
    self.espCountBtn=[self makeCheckBox:self.espView x:col+12 y:169 w:col t:@"Count" a:@selector(onEspCountTapped)];
    self.espBotBtn=[self makeCheckBox:self.espView x:0 y:217 w:w t:@"Show Bot" a:@selector(onEspBotTapped)];
    [self label:@"TARGET SETTINGS" frame:CGRectMake(3,0,w,18) size:11 bold:YES color:NVColor(0x8A9BB3) parent:self.aimView];
    self.aimbotBtn=[self makeCheckBox:self.aimView x:0 y:23 w:w t:@"Enable Aimbot" a:@selector(onAimbotTapped)];
    self.silentAimBtn=[self makeCheckBox:self.aimView x:0 y:68 w:col t:@"Silent Aim" a:@selector(onSilentAimTapped)];
    self.aimKillBtn=[self makeCheckBox:self.aimView x:col+12 y:68 w:col t:@"AimKill" a:@selector(onAimKillTapped)];
    [self label:@"TARGET PART" frame:CGRectMake(3,116,w,15) size:10 bold:YES color:NVColor(0xA7B6C8) parent:self.aimView];
    self.bodyPartSegment=[[UISegmentedControl alloc]initWithItems:@[@"Head",@"Neck",@"Body"]];
    self.bodyPartSegment.frame=CGRectMake(0,134,w,31); self.bodyPartSegment.selectedSegmentIndex=g_aimBodyPart;
    [self.bodyPartSegment addTarget:self action:@selector(bodyPartChanged:) forControlEvents:UIControlEventValueChanged];
    [self.aimView addSubview:self.bodyPartSegment];
    [self label:@"ACTIVATION MODE" frame:CGRectMake(3,174,w,15) size:10 bold:YES color:NVColor(0xA7B6C8) parent:self.aimView];
    self.aimModeSegment=[[UISegmentedControl alloc]initWithItems:@[@"Always",@"Fire",@"Scope",@"F+S"]];
    self.aimModeSegment.frame=CGRectMake(0,191,w,31); self.aimModeSegment.selectedSegmentIndex=g_aimMode;
    [self.aimModeSegment addTarget:self action:@selector(aimModeChanged:) forControlEvents:UIControlEventValueChanged];
    [self.aimView addSubview:self.aimModeSegment];
    self.skipKnockedBtn=[self makeCheckBox:self.aimView x:0 y:232 w:w t:@"Bỏ qua địch gục" a:@selector(onSkipKnockedTapped)];
    [self label:@"FOV SIZE" frame:CGRectMake(3,278,w,15) size:10 bold:YES color:NVColor(0xA7B6C8) parent:self.aimView];
    self.fovSlider=[[UISlider alloc]initWithFrame:CGRectMake(0,295,w,25)];
    self.fovSlider.minimumValue=30; self.fovSlider.maximumValue=500; self.fovSlider.value=g_fov;
    self.fovSlider.minimumTrackTintColor=NVColor(0x29B8D4);
    [self.fovSlider addTarget:self action:@selector(fovChanged:) forControlEvents:UIControlEventValueChanged];
    [self.aimView addSubview:self.fovSlider];
    UIView *profile=[self panel:CGRectMake(0,5,w,96) parent:self.infoView];
    [self label:@"DEVELOPER" frame:CGRectMake(17,13,w-34,18) size:10 bold:YES color:NVColor(0x53D5E9) parent:profile];
    [self label:@"Nguyễn Trung" frame:CGRectMake(17,37,w-34,31) size:23 bold:YES color:UIColor.whiteColor parent:profile];
    [self infoLink:@"ADMIN  ·  @nguyentrungios8" url:@"https://t.me/nguyentrungios8" y:114 width:w];
    [self infoLink:@"CHANNEL  ·  @channelnguyentrung" url:@"https://t.me/channelnguyentrung" y:170 width:w];
    UIView *licensePanel=[self panel:CGRectMake(0,230,w,100) parent:self.infoView];
    [self label:@"LICENSE STATUS" frame:CGRectMake(15,10,w-30,17) size:11 bold:YES color:NVColor(0x53D5E9) parent:licensePanel];
    self.licenseRemainingLabel=[self label:@"Chưa kích hoạt" frame:CGRectMake(15,31,w-30,31) size:22 bold:YES color:UIColor.whiteColor parent:licensePanel];
    self.licenseExpiryLabel=[self label:@"Đang chờ xác thực key" frame:CGRectMake(15,69,w-30,18) size:11 bold:NO color:NVColor(0xA7B6C8) parent:licensePanel];
    [self label:@"NTRUNG VN  •  PREMIUM UI" frame:CGRectMake(3,340,w-6,20) size:10 bold:YES color:NVColor(0x6F8299) parent:self.infoView];
    [self setCheckOn:self.checkESP on:g_master]; [self setCheckOn:self.espBoxBtn on:g_box];
    [self setCheckOn:self.espLineBtn on:g_line]; [self setCheckOn:self.espNameBtn on:g_name];
    [self setCheckOn:self.espDistBtn on:g_dist]; [self setCheckOn:self.espHpBtn on:g_hp];
    [self setCheckOn:self.espCountBtn on:g_count]; [self setCheckOn:self.espBotBtn on:g_bot];
    [self setCheckOn:self.aimbotBtn on:g_aimbot]; [self setCheckOn:self.silentAimBtn on:g_silentAim];
    [self setCheckOn:self.aimKillBtn on:g_aimKill]; [self setCheckOn:self.skipKnockedBtn on:g_skipKnocked];
    [self refreshLicenseStatus];
    self.floatingBtn=[UIButton buttonWithType:UIButtonTypeCustom];
    self.floatingBtn.frame=CGRectMake(sw-68,100,52,52); self.floatingBtn.backgroundColor=NVColor(0x0D1D2C);
    self.floatingBtn.layer.cornerRadius=26; self.floatingBtn.layer.borderWidth=2;
    self.floatingBtn.layer.borderColor=NVColor(0x29B8D4).CGColor;
    [self.floatingBtn addTarget:self action:@selector(openMenu) forControlEvents:UIControlEventTouchUpInside];
    self.floatingBtn.hidden=YES; [self.rootViewController.view addSubview:self.floatingBtn];
    UIImageView *floatingLogo=[[UIImageView alloc]initWithFrame:CGRectMake(6,6,40,40)];
    floatingLogo.layer.cornerRadius=20; floatingLogo.clipsToBounds=YES;
    floatingLogo.contentMode=UIViewContentModeScaleAspectFill; floatingLogo.userInteractionEnabled=NO;
    [self.floatingBtn addSubview:floatingLogo]; [self loadLogo:floatingLogo];
    UIPanGestureRecognizer *fp=[[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(handleFloatPan:)];
    [self.floatingBtn addGestureRecognizer:fp];
    self.menuView.hidden=YES;
    self.floatingBtn.hidden=YES;
    return self;
}
- (void)infoLink:(NSString *)title url:(NSString *)url y:(CGFloat)y width:(CGFloat)w {
    UIButton *b=[UIButton buttonWithType:UIButtonTypeSystem]; b.frame=CGRectMake(0,y,w,46);
    b.layer.cornerRadius=12; b.backgroundColor=NVColor(0x151D2B); b.layer.borderWidth=1;
    b.layer.borderColor=NVColor(0x273346).CGColor; [b setTitle:title forState:UIControlStateNormal];
    [b setTitleColor:NVColor(0xDDECF7) forState:UIControlStateNormal];
    b.titleLabel.font=[UIFont systemFontOfSize:12 weight:UIFontWeightSemibold];
    b.accessibilityIdentifier=url; [b addTarget:self action:@selector(openInfoLink:) forControlEvents:UIControlEventTouchUpInside];
    [self.infoView addSubview:b];
}
- (void)openInfoLink:(UIButton *)b {
    NSURL *u=[NSURL URLWithString:b.accessibilityIdentifier];
    if(u)[[UIApplication sharedApplication]openURL:u options:@{} completionHandler:nil];
}
- (UIButton *)makeCheckBox:(UIView *)p x:(CGFloat)x y:(CGFloat)y w:(CGFloat)w t:(NSString *)t a:(SEL)a {
    UIView *tile=[self panel:CGRectMake(x,y,w,39) parent:p];
    UIButton *b=[UIButton buttonWithType:UIButtonTypeCustom]; b.frame=CGRectMake(9,8,23,23);
    b.layer.cornerRadius=7; b.layer.borderWidth=1; b.layer.borderColor=NVColor(0x53657A).CGColor;
    [b addTarget:self action:a forControlEvents:UIControlEventTouchUpInside]; [tile addSubview:b];
    [self label:t frame:CGRectMake(39,7,w-44,25) size:12 bold:YES color:NVColor(0xE6EFF8) parent:tile];
    UIButton *tap=[UIButton buttonWithType:UIButtonTypeCustom]; tap.frame=CGRectMake(34,0,w-34,39);
    [tap addTarget:self action:a forControlEvents:UIControlEventTouchUpInside]; [tile addSubview:tap]; return b;
}
- (void)setCheckOn:(UIButton *)b on:(BOOL)o {
    b.backgroundColor=o?NVColor(0x29B8D4):NVColor(0x263448);
    [b setTitle:o?@"✓":@"" forState:UIControlStateNormal];
    [b setTitleColor:NVColor(0x08111D) forState:UIControlStateNormal];
    b.titleLabel.font=[UIFont boldSystemFontOfSize:15];
}
- (BOOL)pointInside:(CGPoint)p withEvent:(UIEvent *)e {
    if(!self.menuView.hidden&&[self.menuView pointInside:[self convertPoint:p toView:self.menuView] withEvent:e])return YES;
    if(!self.floatingBtn.hidden&&[self.floatingBtn pointInside:[self convertPoint:p toView:self.floatingBtn] withEvent:e])return YES;
    return NO;
}
- (void)tabChanged:(UISegmentedControl *)s {
    self.espView.hidden=s.selectedSegmentIndex!=0;
    self.aimView.hidden=s.selectedSegmentIndex!=1;
    self.infoView.hidden=s.selectedSegmentIndex!=2;
}
- (void)fovChanged:(UISlider *)s {g_fov=s.value;}
- (void)bodyPartChanged:(UISegmentedControl *)s {g_aimBodyPart=(AimBodyPart)s.selectedSegmentIndex;}
- (void)aimModeChanged:(UISegmentedControl *)s {g_aimMode=(AimMode)s.selectedSegmentIndex;}
- (void)onESPTapped {g_master=!g_master;[self setCheckOn:self.checkESP on:g_master];}
- (void)onEspBoxTapped {g_box=!g_box;[self setCheckOn:self.espBoxBtn on:g_box];}
- (void)onEspLineTapped {g_line=!g_line;[self setCheckOn:self.espLineBtn on:g_line];}
- (void)onEspNameTapped {g_name=!g_name;[self setCheckOn:self.espNameBtn on:g_name];}
- (void)onEspDistTapped {g_dist=!g_dist;[self setCheckOn:self.espDistBtn on:g_dist];}
- (void)onEspHpTapped {g_hp=!g_hp;[self setCheckOn:self.espHpBtn on:g_hp];}
- (void)onEspCountTapped {g_count=!g_count;[self setCheckOn:self.espCountBtn on:g_count];}
- (void)onEspBotTapped {g_bot=!g_bot;[self setCheckOn:self.espBotBtn on:g_bot];}
- (void)onAimbotTapped {g_aimbot=!g_aimbot;[self setCheckOn:self.aimbotBtn on:g_aimbot];}
- (void)onSilentAimTapped {g_silentAim=!g_silentAim;[self setCheckOn:self.silentAimBtn on:g_silentAim];if(g_silentAim)StartSilentAimThread();}
- (void)onAimKillTapped {g_aimKill=!g_aimKill;[self setCheckOn:self.aimKillBtn on:g_aimKill];}
- (void)onSkipKnockedTapped {g_skipKnocked=!g_skipKnocked;[self setCheckOn:self.skipKnockedBtn on:g_skipKnocked];}
- (void)closeMenu {self.menuView.hidden=YES;self.floatingBtn.hidden=NO;}
- (void)openMenu {if(!self.licenseValid)return;self.menuView.hidden=NO;self.floatingBtn.hidden=YES;}
- (void)handlePan:(UIPanGestureRecognizer *)s {
    CGPoint t=[s translationInView:self.rootViewController.view];
    self.menuView.center=CGPointMake(self.menuView.center.x+t.x,self.menuView.center.y+t.y);
    [s setTranslation:CGPointZero inView:self.rootViewController.view];
}
- (void)handleFloatPan:(UIPanGestureRecognizer *)s {
    CGPoint t=[s translationInView:self.rootViewController.view];
    self.floatingBtn.center=CGPointMake(self.floatingBtn.center.x+t.x,self.floatingBtn.center.y+t.y);
    [s setTranslation:CGPointZero inView:self.rootViewController.view];
}
- (void)refreshLicenseStatus {
    NSTimeInterval remaining=self.licenseValid && self.licenseExpiry ? [self.licenseExpiry timeIntervalSinceNow] : 0;
    if(remaining<=0) {
        self.licenseRemainingLabel.text=@"Chưa kích hoạt";
        self.licenseExpiryLabel.text=@"Key hết hạn hoặc chưa xác thực";
        return;
    }
    long long seconds=(long long)ceil(remaining);
    long long days=seconds/86400, hours=(seconds%86400)/3600, minutes=(seconds%3600)/60, secs=seconds%60;
    self.licenseRemainingLabel.text=[NSString stringWithFormat:@"%lld ngày %02lld:%02lld:%02lld",days,hours,minutes,secs];
    NSDateFormatter *fmt=[NSDateFormatter new];fmt.dateFormat=@"dd/MM/yyyy HH:mm:ss";
    self.licenseExpiryLabel.text=[NSString stringWithFormat:@"Hết hạn: %@",[fmt stringFromDate:self.licenseExpiry]];
}
- (void)showLicenseOverlay {
    self.licenseValid=NO;
    g_master=NO;g_aimbot=NO;g_silentAim=NO;g_aimKill=NO;
    self.espLayer.hidden=YES;
    self.menuView.hidden=YES;
    self.floatingBtn.hidden=YES;
    if(!self.licenseOverlay) {
        self.licenseOverlay=[[UIView alloc]initWithFrame:self.bounds];
        self.licenseOverlay.autoresizingMask=UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
        self.licenseOverlay.backgroundColor=NVColor(0x0C121E);
        [self.rootViewController.view addSubview:self.licenseOverlay];
        self.licenseController=[NVLicenseViewController new];
        [self.rootViewController addChildViewController:self.licenseController];
        self.licenseController.view.frame=self.licenseOverlay.bounds;
        self.licenseController.view.autoresizingMask=UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
        [self.licenseOverlay addSubview:self.licenseController.view];
        [self.licenseController didMoveToParentViewController:self.rootViewController];
        __weak typeof(self) weakSelf=self;
        self.licenseController.onActivated=^(NSDate *expires){
            __strong typeof(weakSelf) strongSelf=weakSelf;
            if(!strongSelf)return;
            [strongSelf activateLicenseUntil:expires];
        };
    }
    self.licenseOverlay.hidden=NO;
    [self.rootViewController.view bringSubviewToFront:self.licenseOverlay];
    [self refreshLicenseStatus];
}
- (void)activateLicenseUntil:(NSDate *)expires {
    self.licenseExpiry=expires;
    self.licenseValid=expires && [expires timeIntervalSinceNow]>0;
    if(!self.licenseValid){[self showLicenseOverlay];return;}
    BOOL wasLocked=!self.licenseOverlay.hidden;
    self.licenseOverlay.hidden=YES;
    if(wasLocked){self.menuView.hidden=NO;self.floatingBtn.hidden=YES;}
    [self refreshLicenseStatus];
}
- (void)beginLicenseValidation {
    [self showLicenseOverlay];
    NSString *key=[[NSUserDefaults standardUserDefaults]stringForKey:@"NV_LAST_LICENSE_KEY"];
    if(key.length==0)return;
    self.licenseChecking=YES;
    __weak typeof(self) weakSelf=self;
    [[NVLicenseManager shared]verifyKey:key completion:^(BOOL valid,NSString *message,NSDate *expires){
        __strong typeof(weakSelf) strongSelf=weakSelf;
        if(!strongSelf)return;
        strongSelf.licenseChecking=NO;
        if(valid && expires)[strongSelf activateLicenseUntil:expires];
        else {strongSelf.licenseController.statusLabel.text=message;[strongSelf showLicenseOverlay];}
    }];
}
- (void)revalidateLicense {
    if(!self.licenseValid || self.licenseChecking)return;
    NSString *key=[[NSUserDefaults standardUserDefaults]stringForKey:@"NV_LAST_LICENSE_KEY"];
    if(!key.length){[self showLicenseOverlay];return;}
    self.licenseChecking=YES;
    __weak typeof(self) weakSelf=self;
    [[NVLicenseManager shared]verifyKey:key completion:^(BOOL valid,NSString *message,NSDate *expires){
        __strong typeof(weakSelf) strongSelf=weakSelf;
        if(!strongSelf)return;
        strongSelf.licenseChecking=NO;
        if(valid && expires)[strongSelf activateLicenseUntil:expires];
        else {strongSelf.licenseExpiry=nil;[strongSelf showLicenseOverlay];strongSelf.licenseController.statusLabel.text=message;}
    }];
}
- (void)licenseTick:(NSTimer *)timer {
    if(self.licenseValid && (!self.licenseExpiry || [self.licenseExpiry timeIntervalSinceNow]<=0)){
        [self showLicenseOverlay];return;
    }
    [self refreshLicenseStatus];
}
- (void)tickESP {
    if(!self.licenseValid || !g_master){self.espLayer.hidden=YES;return;}
    self.espLayer.hidden=NO;
    os_unfair_lock_lock(&g_lock);
    self.espLayer.targets=[g_targets copy];
    NSUInteger count=0;for(ESPTarget *t in g_targets.allValues)if(!t.isGhost)count++;
    os_unfair_lock_unlock(&g_lock);
    self.espLayer.countText=g_count?[NSString stringWithFormat:@"Player : %lu",(unsigned long)count]:@"";
    self.espLayer.showLine=g_line;self.espLayer.showBox=g_box;
    self.espLayer.showName=g_name;self.espLayer.showDist=g_dist;
    self.espLayer.showHp=g_hp;
    self.espLayer.showAimFov=(g_aimbot||g_silentAim||g_aimKill);
    [self.espLayer setNeedsDisplay];
}
@end

ModMenuWindow *g_menuWindow = nil;

static void startPolling() {
    [NSTimer scheduledTimerWithTimeInterval:0.016 repeats:YES block:^(NSTimer * _Nonnull timer) {
        @autoreleasepool { pollTick(); }
    }];
}

static void tryFindUnity() {
    for (int i = 0; i < _dyld_image_count(); i++) {
        const char* nm = _dyld_get_image_name(i);
        if (nm && strstr(nm, "UnityFramework")) {
            g_base = (uintptr_t)_dyld_get_image_header(i);
            resolveFns();
            return;
        }
    }
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, NSEC_PER_SEC), dispatch_get_main_queue(), ^{
        [g_menuWindow beginLicenseValidation];
        [NSTimer scheduledTimerWithTimeInterval:1 target:g_menuWindow selector:@selector(licenseTick:) userInfo:nil repeats:YES];
        [NSTimer scheduledTimerWithTimeInterval:60 target:g_menuWindow selector:@selector(revalidateLicense) userInfo:nil repeats:YES];
        tryFindUnity();
    });
}

__attribute__((constructor))
static void init() {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        UIWindow *tw = nil;
        if (@available(iOS 13.0, *)) {
            for (UIScene *scene in [UIApplication sharedApplication].connectedScenes) {
                if ([scene isKindOfClass:[UIWindowScene class]] && scene.activationState == UISceneActivationStateForegroundActive) {
                    tw = ((UIWindowScene *)scene).windows.firstObject;
                    break;
                }
            }
        }
        if (!tw) tw = [UIApplication sharedApplication].windows.firstObject;
        if (!tw) return;

        g_menuWindow = [[ModMenuWindow alloc] initWithFrame:tw.bounds];
        if (@available(iOS 13.0, *)) {
            for (UIScene *scene in [UIApplication sharedApplication].connectedScenes) {
                if ([scene isKindOfClass:[UIWindowScene class]]) {
                    g_menuWindow.windowScene = (UIWindowScene *)scene;
                    break;
                }
            }
        }
        g_menuWindow.hidden = NO;
        [g_menuWindow makeKeyAndVisible];
        objc_setAssociatedObject([UIApplication sharedApplication], "ModMenuWindow", g_menuWindow, OBJC_ASSOCIATION_RETAIN_NONATOMIC);

        tryFindUnity();

        CADisplayLink *link = [CADisplayLink displayLinkWithTarget:g_menuWindow selector:@selector(tickESP)];
        [link addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSRunLoopCommonModes];

        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(10 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            startPolling();
        });
    });
}